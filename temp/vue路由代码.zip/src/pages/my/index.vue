<template>
    <div>
        <headerCom title="我的"></headerCom>
        <div class="main">我的主体内容...</div>
        <footerCom></footerCom>
    </div>
</template>

<script>
import footerCom from '../../components/footercom'
import headerCom from '../../components/headercom'
export default {
    name:'my',
    components: {
        footerCom,
        headerCom,
    }
}
</script>

<style lang="">
    
</style>