<template>
    <div>
        <headerCom title="首页"></headerCom>
        <div class="main">首页主体内容...</div>
        <footerCom></footerCom>
    </div>
</template>

<script>
import footerCom from '../../components/footercom'
import headerCom from '../../components/headercom'
export default {
    name:'home',
    components: {
        footerCom,
        headerCom,
    }
}
</script>

<style lang="">
    
</style>