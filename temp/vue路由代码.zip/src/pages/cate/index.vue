<template>
    <div>
        <headerCom title="分类"></headerCom>
        <div class="main">分类主体内容...</div>
        <footerCom></footerCom>
    </div>
</template>

<script>
import footerCom from '../../components/footercom'
import headerCom from '../../components/headercom'
export default {
    name:'cate',
    components: {
        footerCom,
        headerCom,
    }
}
</script>

<style lang="">
    
</style>