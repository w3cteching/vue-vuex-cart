import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

//引入要跳转的组件
import Home from '../pages/home'
import Cate from '../pages/cate'
import Cart from '../pages/cart'
import My from '../pages/my'


//配置路由
const routes = [
    { path:'/',redirect: '/home' },
    {path:'/home',component:Home},
    {path:'/cate',component:Cate},
    {path:'/Cart',component:Cart},
    {path:'/my',component:My},
]



//实例化路由
const router = new VueRouter({
    routes,
    linkActiveClass:'active'
})

export default router;




