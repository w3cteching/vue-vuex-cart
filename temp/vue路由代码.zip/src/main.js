import Vue from 'vue'
import App from './App.vue'

//引入路由配置
import router from './router'

//引入rem
import './utils/rem'

import '../public/css/reset.css'

Vue.config.productionTip = false

new Vue({
  router,//注入到vue实现中
  render: h => h(App),
}).$mount('#app')
