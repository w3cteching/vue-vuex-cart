const state = {
    num: 100,
    name:'ipad'
}

export default state;