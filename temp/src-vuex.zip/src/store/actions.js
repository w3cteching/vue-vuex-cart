const actions = {
    add({ commit},params) {
        console.log('我是加的方法')
        commit('ADD');
    },
    jian() {

    }

}

export default actions;