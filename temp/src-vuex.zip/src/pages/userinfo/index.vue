<template>
    <div>
        功能列表区域
        <ul>
            <li>支付</li>
            <li>卡包</li>
            <li>设置</li>
        </ul>
    </div>
</template>

<script>
export default {
    name:'userinfo'
}
</script>

<style lang="">
    
</style>