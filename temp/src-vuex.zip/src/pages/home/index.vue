<template>
    <div>
        <div class="main">
            首页主体内容... --
           <button>-</button> {{ num }}<button @click="add">+</button> --{{ name }}
            <ul>
                <li v-for="(item) in list" :key="item.id">
                    {{ item.name }}
                </li>

            </ul>

        </div>

    </div>
</template>

<script>
import {mapState,mapActions} from 'vuex'
import footerCom from '../../components/footercom'
import headerCom from '../../components/headercom'

export default {
    name:'home',
    data() {
        return {
            title:'',
            list:[]
        }
    },
    created() {

        this.getData();
    },
    methods:{
        ...mapActions(['add']),
        getData() {

            console.log('this.$http:',this.$http)

           // this.$http.get('接口地址').then(res=>{})

           this.$http.get('https://cnodejs.org/api/v1/topic/5d5bed6ed53e9171e98a975b',{params:{id:1234}})
                .then(res=>{
                    console.log('res::::',res)
                   // if(res.status==200 && res.data.status==2) {

                      //  this.list=res.data.content;
                   // }
                }).catch(error=>{
                    console.log('error:::',error)
                })
            

         
        },

    },
    computed: {
        /*
        num() {
            return this.$store.state.num;
        }*/
        ...mapState(['num','name'])
    },
    components: {
        footerCom,
        headerCom,
    }
}
</script>

<style lang="">
    
</style>