<template>
    <div>
        头像区域
    </div>
</template>

<script>
export default {
    name:'headicon'
}
</script>

<style lang="">
    
</style>