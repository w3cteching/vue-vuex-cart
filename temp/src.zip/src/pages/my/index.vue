<template>
    <div>
        <headerCom title="我的">
            <template v-slot:login>
                <button @click="goLogin">登录</button>  
               
            </template>
        </headerCom>
        <div class="main">我的主体内容...</div>
        <footerCom></footerCom>
    </div>
</template>

<script>
import footerCom from '../../components/footercom'
import headerCom from '../../components/headercom'
export default {
    name:'my',
    components: {
        footerCom,
        headerCom,
    },
    methods:{
        goLogin() {
           this.$router.push('/login') 
          // this.$router.replace('/login') 
        }
    }
}
</script>

<style lang="">
    
</style>