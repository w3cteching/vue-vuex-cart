<template>
    <div>
        <headerCom title="购物车"></headerCom>
        <div class="main">购物车主体内容...</div>
        <footerCom></footerCom>
    </div>
</template>

<script>
import footerCom from '../../components/footercom'
import headerCom from '../../components/headercom'
export default {
    name:'cart',
    components: {
        footerCom,
        headerCom,
    }
}
</script>

<style lang="">
    
</style>