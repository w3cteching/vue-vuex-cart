<template>
    <div>
     
        <div class="main">首页主体内容...</div>

    </div>
</template>

<script>
import footerCom from '../../components/footercom'
import headerCom from '../../components/headercom'
export default {
    name:'home',
    components: {
        footerCom,
        headerCom,
    }
}
</script>

<style lang="">
    
</style>