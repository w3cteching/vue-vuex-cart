<template>
    <div>
     
        <div class="main">我的主体内容...</div>
      
    </div>
</template>

<script>
import footerCom from '../../components/footercom'
import headerCom from '../../components/headercom'
export default {
    name:'my',
    data() {
        return {
            msg:'明天就要放假拉！！！'
        }
    },
    components: {
        footerCom,
        headerCom,
    },
    methods:{
        goLogin() {
           this.$router.push('/login') 
          // this.$router.replace('/login') 
        }
    },
    beforeRouteEnter(to,from,next) {
        console.log('组件内的钩子：',to);

        if(to.meta.requiredAhur) {
            
           if(localStorage.getItem('user')) {
               next();
           }else {
               next('/login');
           }

        }else {
            next();
        }

        /*
        next(vm=>{
            console.log('this.msg:',vm.msg)
        });
        */

        //next('/home');
    },
    beforeRouteLeave(to,from,next) {
        console.log('beforeRouteLeaveto::::::',to);
       // console.log('beforeRouteLeave::::::',fmro);

        next()
    }
}
</script>

<style lang="">
    
</style>