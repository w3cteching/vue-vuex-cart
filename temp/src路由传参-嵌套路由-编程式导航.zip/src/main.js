import Vue from 'vue'
import App from './App.vue'

//引入路由配置
import router from './router'

//引入rem
import './utils/rem'

import '../public/css/reset.css'

import 'animate.css'

/*
router.beforeEach((to, from, next) => {

  console.log('totototot::::', to);
  to.meta.title &&  (document.title = to.meta.title);
  
  next();

})

router.afterEach( (to,from,next) => {

    console.log('进入之后',to)
})

*/

Vue.config.productionTip = false

new Vue({
  router,//注入到vue实例中
  render: h => h(App),
}).$mount('#app')

