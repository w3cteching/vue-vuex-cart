<template>
  <div id="app">
    <HeaderCom></HeaderCom>
    <transition 
      enter-active-class="animated tada"
      leave-active-class="animated jello"
    
    >
      <router-view></router-view>
    </transition>
    <FooterCom></FooterCom>
  </div>
</template>

<script>
import HeaderCom from './components/headercom'
import FooterCom from './components/footercom'
export default {
  name: 'app',
  components: {
    FooterCom,
    HeaderCom,
  },
}
</script>

<style>
.move-enter-active {
    transition: transform .3s;
}

.move-enter {
    transform: translate3d(-100%,0,0)
}
</style>
