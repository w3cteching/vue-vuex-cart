<template>
    <div>
        您的页面出错啦，请检查一下
    </div>
</template>

<script>
export default {
    name:'404'
}
</script>

<style lang="">
    
</style>